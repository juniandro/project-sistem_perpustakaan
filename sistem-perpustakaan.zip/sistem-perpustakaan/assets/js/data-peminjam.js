// data-peminjam.js
const API_URL = 'http://localhost:3000';
let allPeminjaman = [];

if (!localStorage.getItem('isLoggedIn')) {
    window.location.href = 'login.html';
}

function logout() {
    if (confirm('Yakin ingin logout?')) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    }
}

async function loadPeminjaman() {
    try {
        const response = await fetch(`${API_URL}/peminjaman`);
        allPeminjaman = await response.json();
        displayPeminjaman(allPeminjaman);
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data. Pastikan JSON Server berjalan.');
    }
}

function displayPeminjaman(data) {
    const tbody = document.getElementById('peminjamanTable');
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada data</td></tr>';
        return;
    }
    
    tbody.innerHTML = data.map(p => `
        <tr>
            <td>${p.id_peminjam}</td>
            <td>${p.nama_peminjam}</td>
            <td>${p.judul_buku}</td>
            <td>${p.tanggal_pinjam}</td>
            <td>${p.tanggal_kembali}</td>
            <td><span class="badge badge-${p.status === 'Dipinjam' ? 'warning' : 'success'}">${p.status}</span></td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="editPeminjaman(${p.id})">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deletePeminjaman(${p.id})">Hapus</button>
            </td>
        </tr>
    `).join('');
}

function searchPeminjaman() {
    const keyword = document.getElementById('searchInput').value.toLowerCase();
    const filtered = allPeminjaman.filter(p => 
        p.id_peminjam.toLowerCase().includes(keyword) ||
        p.nama_peminjam.toLowerCase().includes(keyword)
    );
    displayPeminjaman(filtered);
}

async function editPeminjaman(id) {
    try {
        const response = await fetch(`${API_URL}/peminjaman/${id}`);
        const data = await response.json();
        
        document.getElementById('edit_id').value = data.id;
        document.getElementById('edit_nama').value = data.nama_peminjam;
        document.getElementById('edit_judul').value = data.judul_buku;
        document.getElementById('edit_tanggal_pinjam').value = data.tanggal_pinjam;
        document.getElementById('edit_tanggal_kembali').value = data.tanggal_kembali;
        document.getElementById('edit_status').value = data.status;
        
        document.getElementById('editModal').style.display = 'block';
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data');
    }
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

async function deletePeminjaman(id) {
    if (!confirm('Yakin ingin menghapus data ini?')) return;
    
    try {
        // Get peminjaman data to restore book stock if still dipinjam
        const response = await fetch(`${API_URL}/peminjaman/${id}`);
        const peminjaman = await response.json();
        
        if (peminjaman.status === 'Dipinjam') {
            // Find and restore book stock
            const bukuResponse = await fetch(`${API_URL}/buku`);
            const allBuku = await bukuResponse.json();
            const buku = allBuku.find(b => b.kode === peminjaman.kode_buku);
            
            if (buku) {
                await fetch(`${API_URL}/buku/${buku.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ stok: buku.stok + 1 })
                });
            }
        }
        
        await fetch(`${API_URL}/peminjaman/${id}`, {
            method: 'DELETE'
        });
        
        alert('Data berhasil dihapus');
        loadPeminjaman();
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal menghapus data');
    }
}

document.getElementById('editForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const id = document.getElementById('edit_id').value;
    const data = {
        id: parseInt(id),
        id_peminjam: allPeminjaman.find(p => p.id == id).id_peminjam,
        nama_peminjam: document.getElementById('edit_nama').value,
        judul_buku: document.getElementById('edit_judul').value,
        kode_buku: allPeminjaman.find(p => p.id == id).kode_buku,
        tanggal_pinjam: document.getElementById('edit_tanggal_pinjam').value,
        tanggal_kembali: document.getElementById('edit_tanggal_kembali').value,
        lama_pinjam: allPeminjaman.find(p => p.id == id).lama_pinjam,
        status: document.getElementById('edit_status').value,
        denda: allPeminjaman.find(p => p.id == id).denda || 0
    };
    
    try {
        await fetch(`${API_URL}/peminjaman/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        alert('Data berhasil diupdate');
        closeEditModal();
        loadPeminjaman();
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal mengupdate data');
    }
});

window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target === modal) {
        closeEditModal();
    }
}

loadPeminjaman();