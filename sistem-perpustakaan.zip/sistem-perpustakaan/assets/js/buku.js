// buku.js
const API_URL = 'http://localhost:3000';
let allBuku = [];

// Check authentication
if (!localStorage.getItem('isLoggedIn')) {
    window.location.href = 'login.html';
}

function logout() {
    if (confirm('Yakin ingin logout?')) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    }
}

// Load all books
async function loadBuku() {
    try {
        const response = await fetch(`${API_URL}/buku`);
        allBuku = await response.json();
        displayBuku(allBuku);
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data buku. Pastikan JSON Server berjalan.');
    }
}

function displayBuku(buku) {
    const tbody = document.getElementById('bukuTable');
    
    if (buku.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">Tidak ada data</td></tr>';
        return;
    }
    
    tbody.innerHTML = buku.map(b => `
        <tr>
            <td>${b.kode}</td>
            <td>${b.judul}</td>
            <td>${b.pengarang}</td>
            <td>${b.penerbit}</td>
            <td>${b.tahun}</td>
            <td>${b.stok}</td>
            <td>
                <button class="btn btn-warning btn-sm" onclick="editBuku(${b.id})">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deleteBuku(${b.id})">Hapus</button>
            </td>
        </tr>
    `).join('');
}

function searchBuku() {
    const keyword = document.getElementById('searchInput').value.toLowerCase();
    const filtered = allBuku.filter(b => 
        b.judul.toLowerCase().includes(keyword) ||
        b.pengarang.toLowerCase().includes(keyword) ||
        b.kode.toLowerCase().includes(keyword)
    );
    displayBuku(filtered);
}

function openModal() {
    document.getElementById('bukuModal').style.display = 'block';
    document.getElementById('modalTitle').textContent = 'Tambah Buku';
    document.getElementById('bukuForm').reset();
    document.getElementById('bukuId').value = '';
}

function closeModal() {
    document.getElementById('bukuModal').style.display = 'none';
}

async function editBuku(id) {
    try {
        const response = await fetch(`${API_URL}/buku/${id}`);
        const buku = await response.json();
        
        document.getElementById('bukuId').value = buku.id;
        document.getElementById('kode').value = buku.kode;
        document.getElementById('judul').value = buku.judul;
        document.getElementById('pengarang').value = buku.pengarang;
        document.getElementById('penerbit').value = buku.penerbit;
        document.getElementById('tahun').value = buku.tahun;
        document.getElementById('stok').value = buku.stok;
        
        document.getElementById('modalTitle').textContent = 'Edit Buku';
        document.getElementById('bukuModal').style.display = 'block';
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data buku');
    }
}

async function deleteBuku(id) {
    if (!confirm('Yakin ingin menghapus buku ini?')) return;
    
    try {
        await fetch(`${API_URL}/buku/${id}`, {
            method: 'DELETE'
        });
        alert('Buku berhasil dihapus');
        loadBuku();
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal menghapus buku');
    }
}

document.getElementById('bukuForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const id = document.getElementById('bukuId').value;
    const data = {
        kode: document.getElementById('kode').value,
        judul: document.getElementById('judul').value,
        pengarang: document.getElementById('pengarang').value,
        penerbit: document.getElementById('penerbit').value,
        tahun: document.getElementById('tahun').value,
        stok: parseInt(document.getElementById('stok').value)
    };
    
    try {
        if (id) {
            // Update
            await fetch(`${API_URL}/buku/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...data, id: parseInt(id) })
            });
            alert('Buku berhasil diupdate');
        } else {
            // Create
            await fetch(`${API_URL}/buku`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            alert('Buku berhasil ditambahkan');
        }
        
        closeModal();
        loadBuku();
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal menyimpan data');
    }
});

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('bukuModal');
    if (event.target === modal) {
        closeModal();
    }
}

loadBuku();