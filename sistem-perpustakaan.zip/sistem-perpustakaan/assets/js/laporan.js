// laporan.js
const API_URL = 'http://localhost:3000';
let allPeminjaman = [];

if (!localStorage.getItem('isLoggedIn')) {
    window.location.href = 'login.html';
}

function logout() {
    if (confirm('Yakin ingin logout?')) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    }
}

async function loadLaporan() {
    try {
        const response = await fetch(`${API_URL}/peminjaman`);
        allPeminjaman = await response.json();
        
        updateStats();
        displayLaporan(allPeminjaman);
        displayDenda();
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data');
    }
}

function updateStats() {
    const totalTransaksi = allPeminjaman.length;
    const totalDenda = allPeminjaman.reduce((sum, p) => sum + (p.denda || 0), 0);
    const bukuDipinjam = allPeminjaman.filter(p => p.status === 'Dipinjam').length;
    const bukuKembali = allPeminjaman.filter(p => p.status === 'Dikembalikan').length;
    
    document.getElementById('totalTransaksi').textContent = totalTransaksi;
    document.getElementById('totalDendaLaporan').textContent = `Rp ${totalDenda.toLocaleString('id-ID')}`;
    document.getElementById('bukuDipinjamLaporan').textContent = bukuDipinjam;
    document.getElementById('bukuKembaliLaporan').textContent = bukuKembali;
}

function displayLaporan(data) {
    const tbody = document.getElementById('laporanTableBody');
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">Tidak ada data</td></tr>';
        return;
    }
    
    tbody.innerHTML = data.map((p, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${p.id_peminjam}</td>
            <td>${p.nama_peminjam}</td>
            <td>${p.judul_buku}</td>
            <td>${p.tanggal_pinjam}</td>
            <td>${p.tanggal_kembali}</td>
            <td><span class="badge badge-${p.status === 'Dipinjam' ? 'warning' : 'success'}">${p.status}</span></td>
            <td>Rp ${(p.denda || 0).toLocaleString('id-ID')}</td>
        </tr>
    `).join('');
}

function displayDenda() {
    const tbody = document.getElementById('dendaTableBody');
    const dendaData = allPeminjaman.filter(p => p.denda > 0);
    
    if (dendaData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">Tidak ada denda</td></tr>';
        return;
    }
    
    tbody.innerHTML = dendaData.map((p, index) => {
        const hariTerlambat = Math.ceil(p.denda / 1000);
        return `
            <tr>
                <td>${index + 1}</td>
                <td>${p.id_peminjam}</td>
                <td>${p.nama_peminjam}</td>
                <td>${p.judul_buku}</td>
                <td>${hariTerlambat} Hari</td>
                <td>Rp ${p.denda.toLocaleString('id-ID')}</td>
            </tr>
        `;
    }).join('');
}

function filterLaporan() {
    const status = document.getElementById('filterStatus').value;
    
    if (status === '') {
        displayLaporan(allPeminjaman);
    } else {
        const filtered = allPeminjaman.filter(p => p.status === status);
        displayLaporan(filtered);
    }
}

function exportLaporan() {
    // Simple CSV export
    let csv = 'No,ID Peminjam,Nama,Judul Buku,Tanggal Pinjam,Tanggal Kembali,Status,Denda\n';
    
    allPeminjaman.forEach((p, index) => {
        csv += `${index + 1},"${p.id_peminjam}","${p.nama_peminjam}","${p.judul_buku}","${p.tanggal_pinjam}","${p.tanggal_kembali}","${p.status}","${p.denda || 0}"\n`;
    });
    
    // Create download link
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `laporan_perpustakaan_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert('Laporan berhasil diexport!');
}

loadLaporan();