// pengembalian.js
const API_URL = 'http://localhost:3000';
const DENDA_PER_HARI = 1000;

if (!localStorage.getItem('isLoggedIn')) {
    window.location.href = 'login.html';
}

function logout() {
    if (confirm('Yakin ingin logout?')) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    }
}

async function loadPeminjamanAktif() {
    try {
        const response = await fetch(`${API_URL}/peminjaman`);
        const allPeminjaman = await response.json();
        const aktif = allPeminjaman.filter(p => p.status === 'Dipinjam');
        
        displayPengembalian(aktif);
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data');
    }
}

function hitungDenda(tanggalKembali) {
    const today = new Date();
    const kembali = new Date(tanggalKembali);
    
    // Reset time to midnight for accurate date comparison
    today.setHours(0, 0, 0, 0);
    kembali.setHours(0, 0, 0, 0);
    
    const diffTime = today - kembali;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays > 0) {
        return {
            hari: diffDays,
            denda: diffDays * DENDA_PER_HARI
        };
    }
    
    return { hari: 0, denda: 0 };
}

function displayPengembalian(data) {
    const tbody = document.getElementById('pengembalianTable');
    
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">Tidak ada buku yang dipinjam</td></tr>';
        return;
    }
    
    tbody.innerHTML = data.map(p => {
        const { hari, denda } = hitungDenda(p.tanggal_kembali);
        const statusClass = hari > 0 ? 'badge-danger' : 'badge-success';
        const statusText = hari > 0 ? `${hari} Hari` : 'Tepat Waktu';
        
        return `
            <tr>
                <td>${p.id_peminjam}</td>
                <td>${p.nama_peminjam}</td>
                <td>${p.judul_buku}</td>
                <td>${p.tanggal_pinjam}</td>
                <td>${p.tanggal_kembali}</td>
                <td><span class="badge ${statusClass}">${statusText}</span></td>
                <td>Rp ${denda.toLocaleString('id-ID')}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="konfirmasiKembali(${p.id})">
                        Kembalikan
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

async function konfirmasiKembali(id) {
    try {
        const response = await fetch(`${API_URL}/peminjaman/${id}`);
        const data = await response.json();
        
        const { hari, denda } = hitungDenda(data.tanggal_kembali);
        
        document.getElementById('return_id').value = data.id;
        document.getElementById('confirm_nama').textContent = data.nama_peminjam;
        document.getElementById('confirm_judul').textContent = data.judul_buku;
        document.getElementById('confirm_tanggal').textContent = data.tanggal_kembali;
        document.getElementById('confirm_terlambat').textContent = hari;
        document.getElementById('confirm_denda').textContent = `Rp ${denda.toLocaleString('id-ID')}`;
        
        document.getElementById('konfirmasiModal').style.display = 'block';
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memuat data');
    }
}

function closeKonfirmasiModal() {
    document.getElementById('konfirmasiModal').style.display = 'none';
}

async function prosesKembali() {
    const id = document.getElementById('return_id').value;
    
    try {
        // Get peminjaman data
        const response = await fetch(`${API_URL}/peminjaman/${id}`);
        const peminjaman = await response.json();
        
        const { hari, denda } = hitungDenda(peminjaman.tanggal_kembali);
        
        // Update peminjaman status
        await fetch(`${API_URL}/peminjaman/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                status: 'Dikembalikan',
                denda: denda,
                tanggal_dikembalikan: new Date().toISOString().split('T')[0]
            })
        });
        
        // Return book stock
        const bukuResponse = await fetch(`${API_URL}/buku`);
        const allBuku = await bukuResponse.json();
        const buku = allBuku.find(b => b.kode === peminjaman.kode_buku);
        
        if (buku) {
            await fetch(`${API_URL}/buku/${buku.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ stok: buku.stok + 1 })
            });
        }
        
        alert(`Pengembalian berhasil!\nDenda: Rp ${denda.toLocaleString('id-ID')}`);
        closeKonfirmasiModal();
        loadPeminjamanAktif();
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal memproses pengembalian');
    }
}

window.onclick = function(event) {
    const modal = document.getElementById('konfirmasiModal');
    if (event.target === modal) {
        closeKonfirmasiModal();
    }
}

loadPeminjamanAktif();