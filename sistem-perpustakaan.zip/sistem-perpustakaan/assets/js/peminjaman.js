// peminjaman.js
const API_URL = 'http://localhost:3000';
let allBuku = [];

if (!localStorage.getItem('isLoggedIn')) {
    window.location.href = 'login.html';
}

function logout() {
    if (confirm('Yakin ingin logout?')) {
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    }
}

// Load books for search
async function loadBukuData() {
    try {
        const response = await fetch(`${API_URL}/buku`);
        allBuku = await response.json();
    } catch (error) {
        console.error('Error:', error);
    }
}

function searchBukuPinjam() {
    const keyword = document.getElementById('searchBuku').value.toLowerCase();
    const bukuList = document.getElementById('bukuList');
    
    if (keyword.length < 2) {
        bukuList.style.display = 'none';
        return;
    }
    
    const filtered = allBuku.filter(b => 
        b.judul.toLowerCase().includes(keyword) && b.stok > 0
    );
    
    if (filtered.length === 0) {
        bukuList.innerHTML = '<div class="dropdown-item">Buku tidak ditemukan atau stok habis</div>';
        bukuList.style.display = 'block';
        return;
    }
    
    bukuList.innerHTML = filtered.map(b => `
        <div class="dropdown-item" onclick="pilihBuku('${b.kode}', '${b.judul}')">
            ${b.judul} - ${b.pengarang} (Stok: ${b.stok})
        </div>
    `).join('');
    bukuList.style.display = 'block';
}

function pilihBuku(kode, judul) {
    document.getElementById('kode_buku').value = kode;
    document.getElementById('judul_buku').value = judul;
    document.getElementById('searchBuku').value = judul;
    document.getElementById('bukuList').style.display = 'none';
}

function hitungTanggalKembali() {
    const tanggalPinjam = document.getElementById('tanggal_pinjam').value;
    const lamaPinjam = parseInt(document.getElementById('lama_pinjam').value);
    
    if (tanggalPinjam && lamaPinjam) {
        const pinjam = new Date(tanggalPinjam);
        pinjam.setDate(pinjam.getDate() + lamaPinjam);
        
        const year = pinjam.getFullYear();
        const month = String(pinjam.getMonth() + 1).padStart(2, '0');
        const day = String(pinjam.getDate()).padStart(2, '0');
        
        document.getElementById('tanggal_kembali').value = `${year}-${month}-${day}`;
    }
}

// Set today as default
const today = new Date().toISOString().split('T')[0];
document.getElementById('tanggal_pinjam').value = today;
document.getElementById('tanggal_pinjam').addEventListener('change', hitungTanggalKembali);
hitungTanggalKembali();

document.getElementById('peminjamanForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const kodeBuku = document.getElementById('kode_buku').value;
    if (!kodeBuku) {
        alert('Silakan pilih buku terlebih dahulu');
        return;
    }
    
    // Find book and reduce stock
    const buku = allBuku.find(b => b.kode === kodeBuku);
    if (!buku || buku.stok <= 0) {
        alert('Buku tidak tersedia atau stok habis');
        return;
    }
    
    const data = {
        id_peminjam: document.getElementById('id_peminjam').value,
        nama_peminjam: document.getElementById('nama_peminjam').value,
        judul_buku: document.getElementById('judul_buku').value,
        kode_buku: kodeBuku,
        tanggal_pinjam: document.getElementById('tanggal_pinjam').value,
        tanggal_kembali: document.getElementById('tanggal_kembali').value,
        lama_pinjam: parseInt(document.getElementById('lama_pinjam').value),
        status: 'Dipinjam',
        denda: 0
    };
    
    try {
        // Add peminjaman
        await fetch(`${API_URL}/peminjaman`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        // Update book stock
        await fetch(`${API_URL}/buku/${buku.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ stok: buku.stok - 1 })
        });
        
        alert('Peminjaman berhasil dicatat');
        this.reset();
        document.getElementById('tanggal_pinjam').value = today;
        document.getElementById('kode_buku').value = '';
        hitungTanggalKembali();
        loadBukuData();
        
        // Redirect to data peminjaman
        if (confirm('Lihat data peminjaman?')) {
            window.location.href = 'data-peminjam.html';
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Gagal menyimpan peminjaman');
    }
});

// Close dropdown when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('.form-group')) {
        document.getElementById('bukuList').style.display = 'none';
    }
});

loadBukuData();